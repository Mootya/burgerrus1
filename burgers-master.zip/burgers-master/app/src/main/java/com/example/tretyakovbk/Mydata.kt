package com.example.tretyakovbk

data class guide(val title:String, val desc: String, val image: Int)

object list {
    val list = arrayListOf(
        guide
            (
            "Быстрая доставка!",
            "Наши сотрудники выезжают очень n оперативно и быстро!",
            R.drawable.kurier
        ),
        guide
            (
            "Работаем круглосуточно",
            "Мы можем принимать ваши заказы постоянно!",
            R.drawable.krug
        ),
        guide
            (
            "Хорошее обслуживание",
            "Самое лучшее обслуживание!",
            R.drawable.obsluga
        )
    )
}
